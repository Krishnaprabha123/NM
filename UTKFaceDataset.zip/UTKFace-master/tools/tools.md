# face detection algorithm and code

## [DPM ECCV 2014](https://markusmathias.bitbucket.io/2014_eccv_face_detection/) 
 
## [Viola-Jones IJCV 2004] ()

## [SCD: SURF-Cascade Detection cvpr13](http://libccv.org/doc/doc-scd/)
 
# face pointe detector

## [CVPR 2013](http://mmlab.ie.cuhk.edu.hk/archive/CNN_FacePoint.htm)

# age and gender estimation

## [Adience CVPR 2015](http://www.openu.ac.il/home/hassner/projects/cnn_agegender/)
## [DEX ICCVW 2015](https://data.vision.ee.ethz.ch/cvl/rrothe/imdb-wiki/)
